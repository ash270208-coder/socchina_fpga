SWNS: -1.675ns, STNS: -42.032ns.
HWNS: -0.377ns, HTNS: -1.885ns.
