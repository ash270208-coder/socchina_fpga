
`timescale 1ns/1ps

module ram_5b7716d404a0 (
	
	dia, 
	addra, 
	
	cea, 
	
	clka, 
	
	addrb, 
	
	ceb, 
	
	clkb,
	
	dob
	
);

	parameter DATA_WIDTH_A = 20; 
	parameter ADDR_WIDTH_A = 10;
	parameter DATA_DEPTH_A = 1024;
	parameter DATA_WIDTH_B = DATA_WIDTH_A;
	parameter ADDR_WIDTH_B = ADDR_WIDTH_A;
	parameter DATA_DEPTH_B = DATA_DEPTH_A;
	
	parameter REGMODE_A    = "NOREG";
	parameter REGMODE_B    = "OUTREG";
	parameter WRITEMODE_A  = "NORMAL";
	parameter WRITEMODE_B  = "NORMAL";
	parameter RESETMODE_A  = "ASYNC";
	parameter RESETMODE_B  = "ASYNC";
	
	parameter INIT_FILE    ="NONE";
	parameter FILL_ALL     ="NONE";

	output [DATA_WIDTH_B-1:0] dob;
	input  [DATA_WIDTH_A-1:0] dia;
	input  [ADDR_WIDTH_A-1:0] addra;
	input  [ADDR_WIDTH_B-1:0] addrb;
	
	input  cea;
	
	input  ceb;
	
	input  clka;
	
	input  clkb;
	
	PH1P_LOGIC_ERAM #( 
	
		.DATA_WIDTH_A(DATA_WIDTH_A),
		.DATA_WIDTH_B(DATA_WIDTH_B),
		.ADDR_WIDTH_A(ADDR_WIDTH_A),
		.ADDR_WIDTH_B(ADDR_WIDTH_B),
		.DATA_DEPTH_A(DATA_DEPTH_A),
		.DATA_DEPTH_B(DATA_DEPTH_B),
		
		.MODE("PDPW"),
		.REGMODE_A(REGMODE_A),
		.REGMODE_B(REGMODE_B),
		.WRITEMODE_A(WRITEMODE_A),
		.WRITEMODE_B(WRITEMODE_B),
		
		.IMPLEMENT("20K"),
		
		.ECC_ENCODE("DISABLE"),
		
		.ECC_DECODE("DISABLE"),
		
		.CLKMODE("ASYNC"),
		
		.SSROVERCE("DISABLE"),
		
		.OREGSET_A("SET"),
		
		.OREGSET_B("SET"),
		
		.RESETMODE_A(RESETMODE_A),
		.RESETMODE_B(RESETMODE_B),
		
		.ASYNC_RESET_RELEASE_A("ASYNC"),
		
		.ASYNC_RESET_RELEASE_B("SYNC"),
		
		.INIT_FILE(INIT_FILE),
		.FILL_ALL(FILL_ALL)
		
	) username_inst(
		
		.dia(dia),
		.dib({DATA_WIDTH_B{1'b0}}),
		.addra(addra),
		.addrb(addrb),
		
		.cea(cea),
		
		.ceb(ceb),
		
		.ocea(1'b0),
		
		.oceb(1'b0),
		
		.clka(clka),
		
		.clkb(clkb),
		
		.wea(1'b1),
		
		.web(1'b0),
		
		.bea(1'b0),
		
		.beb(1'b0),
		.rsta(1'b0),
		
		.rstb(1'b0),
		
		.ecc_sbiterr(),
		.ecc_dbiterr(),
		
		.ecc_sbiterrinj(),
		
		.ecc_dbiterrinj(),
		
		.doa(),
		.dob(dob)
		
	);

endmodule
