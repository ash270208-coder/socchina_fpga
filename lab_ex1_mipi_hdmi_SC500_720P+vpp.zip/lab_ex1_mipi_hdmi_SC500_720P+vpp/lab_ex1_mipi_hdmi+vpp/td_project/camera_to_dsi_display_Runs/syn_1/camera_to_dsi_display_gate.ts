SWNS: -0.200ns, STNS: -2.000ns.
HWNS: -0.377ns, HTNS: -1.885ns.
