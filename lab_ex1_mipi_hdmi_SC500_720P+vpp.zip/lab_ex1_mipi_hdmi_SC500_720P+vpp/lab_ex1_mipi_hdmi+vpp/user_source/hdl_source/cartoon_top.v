`timescale 1ns / 1ps

module cartoon_top #(
    parameter IMG_WIDTH        = 1280,
    parameter IMG_HEIGHT       = 720,
    parameter SOBEL_THRESHOLD  = 70,
    parameter QUANT_BITS       = 4
)(
    input               I_clk,
    input               I_rst_n,

    input               I_tlast,
    input               I_tuser,
    input      [23:0]   I_tdata,
    input               I_tvalid,
    input               I_tready,

    output reg [23:0]   O_tdata,
    output reg          O_tlast,
    output reg          O_tuser,
    output reg          O_tvalid,
    output              O_tready
);

    // =========================================================================
    // 卡通化算法顶层集成模块 (Cartoon Top)
    // =========================================================================
    // 2026 嵌赛 FPGA 选题二：卡通化图像风格化处理
    // 流水线：3x3 双边降噪 + 边缘提取 + 3x3 膨胀加粗 + 区域填充，色度低位量化方案
    //
    // 数据通路 (按本工程实际拍数标注):
    //   输入 RGB888 ─┬─ RGB888_YCbCr444(3拍) ─ bilateral_filter_3x3(8拍) ─ Sobel_edge(5拍) ─ sobel_mask [cycle 16]
    //                │                                                                         └─ Bit_Dilation_Detector(4拍) ─ edge_dilated [cycle 20]
    //                └─ Color_Quantize(2拍) ─ 延时链(+18拍) ─ quant_rgb_aligned [cycle 20]
    //   Cartoon_Blend(0拍，组合逻辑) ─ 输出寄存器(1拍) ─ O_tdata  [cycle 21]
    //
    // 两路数据在 cycle 20 严格对齐后喂入 Cartoon_Blend，防止帧撕裂。
    //
    // 【重要】本工程 user_source/hdl_source/Sobel_edge.v 是 5 级流水线输出，
    //         而 fang 分支卡通目录里那份 Sobel_edge 只有 4 级。延时链必须取
    //         18 拍 (2+18 = 3+8+5+4) 才能对齐，即 QUANT_EXTRA_DLY = 18。
    //         若以后换回 4 级 Sobel，把 QUANT_EXTRA_DLY 改回 17 即可。
    // =========================================================================

    // =========================================================================
    // 1. RGB888 转 Y888（只取亮度 Y）
    //    流水线延迟：3 拍 (cycle 3 输出)，与原来的 RGB888_YCbCr444 完全一致。
    //
    //    【为什么换成 RGB888_Y888】原来这里用 RGB888_YCbCr444，会算 Y+Cb+Cr
    //    共 9 个乘法器，但本模块只用 Y（Cb/Cr 接出来从没被用到）。换成只算 Y
    //    的通用模块后：口径一致（全工程三处取亮度都用同一个模块、同一组系数）、
    //    端口干净、少 6 个乘法器的布线面积。Y 的定点完全没变，所以卡通观感不变。
    // =========================================================================
    wire        tlast_ycbcr;
    wire        tuser_ycbcr;
    wire        tvalid_ycbcr;
    wire [7:0]  y_tdata;

    RGB888_Y888 #(
        .IMG_WIDTH (IMG_WIDTH),
        .IMG_HEIGHT(IMG_HEIGHT)
    ) u_rgb2y (
        .I_clk          (I_clk),
        .I_rst_n        (I_rst_n),
        .I_tlast        (I_tlast),
        .I_tuser        (I_tuser),
        .I_red_tdata    (I_tdata[23:16]),
        .I_green_tdata  (I_tdata[15:8]),
        .I_blue_tdata   (I_tdata[7:0]),
        .I_tvalid       (I_tvalid),
        .I_tready       (I_tready),
        .O_tlast        (tlast_ycbcr),
        .O_tuser        (tuser_ycbcr),
        .O_y_tdata      (y_tdata),
        .O_tvalid       (tvalid_ycbcr),
        .O_tready       ()
    );

    // =========================================================================
    // 2. 3x3 双边滤波 (bilateral_filter_3x3, 对 Y 灰度做保边缘降噪)
    //    空间核 [1 2 1;2 4 2;1 2 1] + 高斯距离核(σr=35): 平滑平区噪声的同时
    //    保留大梯度边缘, 避免普通低通把描边磨淡。是"噪点太多"的治本方案。
    //    流水线延迟：8 拍 (从 ycbcr 输出算起, cycle 11 输出)
    // =========================================================================
    wire        tlast_lp;
    wire        tuser_lp;
    wire        tvalid_lp;
    wire [7:0]  y_lp;

    bilateral_filter_3x3 #(
        .IMG_WIDTH (IMG_WIDTH),
        .IMG_HEIGHT(IMG_HEIGHT)
    ) u_bilateral_filter (
        .I_clk         (I_clk),
        .I_rst_n       (I_rst_n),
        .I_tvalid      (tvalid_ycbcr),
        .I_tuser       (tuser_ycbcr),
        .I_tlast       (tlast_ycbcr),
        .I_grey_tdata  (y_tdata),
        .O_tvalid      (tvalid_lp),
        .O_tuser       (tuser_lp),
        .O_tlast       (tlast_lp),
        .O_grey_tdata  (y_lp)
    );

    // =========================================================================
    // 3. Sobel 边缘检测 (对双边滤波后的 Y 灰度做边缘提取，输出二值 mask)
    //    I_grey_tdata 输入 Y，O_grey_tdata 输出二值 mask (8'hFF=边缘, 8'h00=非边缘)
    //    流水线延迟：5 拍 (本工程 Sobel_edge 为 5 级流水, 从双边输出算起)
    //    Sobel 路径总延迟 = 3 + 8 + 5 = 16 拍 (cycle 16 输出)
    // =========================================================================
    wire        tlast_sobel;
    wire        tuser_sobel;
    wire        tvalid_sobel;
    wire [7:0]  sobel_mask;

    Sobel_edge #(
        .IMG_WIDTH       (IMG_WIDTH),
        .IMG_HEIGHT      (IMG_HEIGHT),
        .SOBEL_THRESHOLD (SOBEL_THRESHOLD)
    ) u_Sobel_edge (
        .I_clk          (I_clk),
        .I_rst_n        (I_rst_n),
        .I_tlast        (tlast_lp),
        .I_tuser        (tuser_lp),
        .I_grey_tdata   (y_lp),
        .I_tvalid       (tvalid_lp),
        .O_tlast        (tlast_sobel),
        .O_tuser        (tuser_sobel),
        .O_grey_tdata   (sobel_mask),
        .O_tvalid       (tvalid_sobel)
    );

    // =========================================================================
    // 4. 颜色量化 (Color Quantize，低位量化海报化色块)
    //    直接量化输入 RGB888，每通道保留 QUANT_BITS 高位，低位补零
    //    流水线延迟：2 拍 (cycle 2 输出)
    // =========================================================================
    wire        tlast_quant;
    wire        tuser_quant;
    wire        tvalid_quant;
    wire [23:0] quant_rgb;

    Color_Quantize #(
        .QUANT_BITS (QUANT_BITS)
    ) u_Color_Quantize (
        .I_clk      (I_clk),
        .I_rst_n    (I_rst_n),
        .I_tlast    (I_tlast),
        .I_tuser    (I_tuser),
        .I_tdata    (I_tdata),
        .I_tvalid   (I_tvalid),
        .O_tlast    (tlast_quant),
        .O_tuser    (tuser_quant),
        .O_tdata    (quant_rgb),
        .O_tvalid   (tvalid_quant)
    );

    // =========================================================================
    // 5. 延时对齐链 (Delay Alignment)
    //    Sobel 路径总延迟 = RGB2YCbCr(3拍) + 双边(8拍) + Sobel(5拍) + 膨胀(4拍) = 20 拍
    //    Color_Quantize 路径延迟 = 2 拍
    //    差值 = 20 - 2 = 18 拍 → quant_rgb 需额外延迟 18 拍
    //    对齐后两路数据均在 cycle 20 到达 Cartoon_Blend 输入端
    //    控制信号使用 tlast/tuser/tvalid_dilate (已在 cycle 20)
    // =========================================================================
    localparam QUANT_EXTRA_DLY = 18;
    reg [23:0] quant_rgb_d [0:QUANT_EXTRA_DLY-1];

    integer i;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            for (i = 0; i < QUANT_EXTRA_DLY; i = i + 1)
                quant_rgb_d[i] <= 24'd0;
        end
        else if (I_tready) begin
            quant_rgb_d[0] <= quant_rgb;
            for (i = 0; i < QUANT_EXTRA_DLY - 1; i = i + 1)
                quant_rgb_d[i+1] <= quant_rgb_d[i];
        end
    end

    // 对齐后的量化 RGB (cycle 20)
    wire [23:0] quant_rgb_aligned = quant_rgb_d[QUANT_EXTRA_DLY-1];

    // =========================================================================
    // 6. 3x3 膨胀 (Bit Dilation，加粗黑边)
    //    Sobel 输出边缘 mask 取 bit0 作为 1bit 边缘，再做 3x3 膨胀加粗
    //    流水线延迟：4 拍 (从 sobel 输出算起) -> edge_dilated [cycle 20]
    // =========================================================================
    wire sobel_edge = sobel_mask[0];

    wire        tvalid_dilate;
    wire        tlast_dilate;
    wire        tuser_dilate;
    wire        edge_dilated;

    Bit_Dilation_Detector #(
        .IMG_WIDTH (IMG_WIDTH),
        .IMG_HEIGHT(IMG_HEIGHT)
    ) u_Bit_Dilation_Detector (
        .I_clk          (I_clk),
        .I_rst_n        (I_rst_n),
        .I_tlast        (tlast_sobel),
        .I_tuser        (tuser_sobel),
        .I_per_img_Bit  (sobel_edge),
        .I_tvalid       (tvalid_sobel),
        .O_tlast        (tlast_dilate),
        .O_tuser        (tuser_dilate),
        .O_per_img_Bit  (edge_dilated),
        .O_tvalid       (tvalid_dilate)
    );

    // =========================================================================
    // 7. 卡通化边缘合成 (Cartoon Blend)
    //    输入两路已在 cycle 20 对齐的数据：
    //      - quant_rgb_aligned : 量化色块 RGB888
    //      - edge_dilated      : 膨胀后的边缘标志 (1=边缘, 0=非边缘)
    //    纯组合逻辑 (0 拍延迟)，边缘位置输出黑色描边，非边缘透传色块
    // =========================================================================
    wire        tlast_blend;
    wire        tuser_blend;
    wire        tvalid_blend;
    wire [23:0] blend_rgb;

    Cartoon_Blend #(
        .IMG_WIDTH (IMG_WIDTH),
        .IMG_HEIGHT(IMG_HEIGHT)
    ) u_Cartoon_Blend (
        .I_clk          (I_clk),
        .I_rst_n        (I_rst_n),
        .I_tlast        (tlast_dilate),
        .I_tuser        (tuser_dilate),
        .I_color_tdata  (quant_rgb_aligned),
        .I_edge_flag    (edge_dilated),   // 用膨胀后的边缘
        .I_tvalid       (tvalid_dilate),
        .O_tlast        (tlast_blend),
        .O_tuser        (tuser_blend),
        .O_tdata        (blend_rgb),
        .O_tvalid       (tvalid_blend)
    );

    // =========================================================================
    // 8. 输出寄存器 (额外打 1 拍，改善时序，cycle 21 输出)
    // =========================================================================
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_tdata  <= 24'd0;
            O_tlast  <= 1'b0;
            O_tuser  <= 1'b0;
            O_tvalid <= 1'b0;
        end
        else begin
            O_tdata  <= blend_rgb;
            O_tlast  <= tlast_blend;
            O_tuser  <= tuser_blend;
            O_tvalid <= tvalid_blend;
        end
    end

    // ready 信号透传（无反压逻辑，与 vpp_top 风格一致）
    assign O_tready = I_tready;

endmodule